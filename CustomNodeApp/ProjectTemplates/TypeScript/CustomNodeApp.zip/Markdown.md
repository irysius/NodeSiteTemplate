﻿# Markdown Sample

This is a **bolded** text.

This is an *italicized* text.

## Lists

### Unordered Lists
* Item
* Item
* Item

### Ordered Lists
1. Item One
2. Item Two
3. Item Three

## Code Stuff

Press `Ctrl+C` to copy, and `Ctrl+V` to paste.

	# To Update Modules
	$ cd /path/to/your/project
	$ npm update

## Links
Read more about Markdown [here](http://daringfireball.net/projects/markdown/syntax).